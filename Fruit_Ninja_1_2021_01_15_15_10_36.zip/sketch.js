var sword, swordi;
var fruit1, fruit1i, fruit2, fruit2i, fruit3, fruit3i, fruit4, fruit4i;

var f1Group, f2Group, f3Group, f4Group, alienGroup;
var Score=0;
var alien, alieni;
var gameover,gameoveri;


function preload(){
  
  swordi=loadImage("sword.png");
  fruit1i=loadImage("fruit1.png");
  fruit2i=loadImage("fruit2.png");
  fruit3i=loadImage("fruit3.png");
  fruit4i=loadImage("fruit4.png");
  alieni=loadImage("alien1.png");
  gameoveri=loadImage("gameover.png");
  
}
function setup () {
  createCanvas(600,600);
  
  sword = createSprite(300,150,20,20);
  sword.addImage("S", swordi);
  sword.scale=0.4;
  sword.debug=true;
  
 
  
 
  f1Group=new Group();
  f2Group=new Group();
  f3Group=new Group();
  f4Group=new Group();
  alienGroup=new Group();
  
  
  
 
  
}
function draw(){
background("skyblue");
  
  sword.y=mouseY
  sword.x=mouseX
  
  
  Fruit1();
  Fruit2();
  Fruit3();
  Fruit4();
  Enemy();
  
  if (sword.isTouching(f1Group)) {
    f1Group.destroyEach();
     Score=Score+2;
  }
  
  
  if (sword.isTouching(f2Group)) {
    f2Group.destroyEach();
     Score=Score+2;
  }
  
   if (sword.isTouching(f3Group)) {
    f3Group.destroyEach();
      Score=Score+2;
  }
  
  
   if (sword.isTouching(f4Group)) {
    f4Group.destroyEach();
      Score=Score+2;
  }
  
  
  
  
   if (alienGroup.isTouching(sword)) {
    
    alienGroup.destroyEach();
   
     
     gameover=createSprite(300,300,10,10);
  gameover.addImage("G", gameoveri);
  
    fruit1.velocity=0;
    fruit2.velocity=0;
     fruit3.velocity=0;
     fruit4.velocity=0;
     sword.x=300;
     sword.y=300;
    
     Score=Score+0;
  }
  text("Score:" + Score, 200,100)
  drawSprites();
  
  
}

function Fruit1() {
  if (frameCount%70===0) {
    fruit1 = createSprite(0,Math.round(random(0,250)),20,20);
  fruit1.addImage("R", fruit1i);
  fruit1.velocityX=10;
  
  fruit1.scale=0.2;
    f1Group.add(fruit1);
    fruit1.debug=true;
  }
  }
  
  function Fruit2() {
  if (frameCount%80===0) {
    fruit2 = createSprite(30,Math.round(random(30,550)),10,20);
  fruit2.addImage("T", fruit2i);
  fruit2.velocityX=4;
  //velocityY=-4;
  fruit2.scale=0.2;
    f2Group.add(fruit2);
  
  }
  }
  
  function Fruit3() {
  if (frameCount%80===0) {
    fruit3 = createSprite(0,Math.round(random(550,50)),20,20);
  fruit3.addImage("T", fruit3i);
  fruit3.velocityX=4;
  //velocityY=-4;
  fruit3.scale=0.2;
  f3Group.add(fruit3);
  
  }
  }
  
  function Fruit4() {
  if (frameCount%60===0) {
    fruit4 = createSprite(0,Math.round(random(130,550)),20,20);
  fruit4.addImage("T", fruit4i);
  fruit4.velocityX=4
  //velocityY=4
  f4Group.add(fruit4);
  fruit4.scale=0.2;
    fruit4.debug=true;
   
  
  }
  }

function Enemy() {
  if (frameCount%90===0) {
    alien=createSprite(0,Math.round(random(130,400)),20,20);
    alien.addImage("A", alieni);
    alien.velocityX=5;
    alienGroup.add(alien);
     
    
  }
}
  